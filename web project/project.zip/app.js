const express = require("express");
const mongoose = require("mongoose");
const shirtmodel = require("./Models/shirt");
let server = express();
server.use(express.json());
server.use(express.urlencoded());
server.set("view engine", "ejs");
server.use(express.static("public"));
//mongoose accepts a connection string to your db and attempts a connections here
mongoose.connect("mongodb://127.0.0.1:27017/project").then((data) => {
  console.log("DB Connected");
});

server.get("/shirt", async (req, res) => {
  const data = await shirtmodel.find();
  console.log(data);

  res.render("shirts", { data });
});

server.listen(3000, () => {
  console.log("Server started at localhost:3000");
});
