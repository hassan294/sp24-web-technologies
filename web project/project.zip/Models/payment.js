const mongoose = require("mongoose");

const payment=new mongoose.Schema({

    
})