const mongoose = require("mongoose");

const customer = new mongoose.Schema({
  customer_id: { type: Number, default: 1 },
  customer_name: String,
  customer_contact: String,
  customer_address: String,
});
